package com.example.fastcampusmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastcampusMysqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
