package com.example.fastcampusmysql.domain.post.dto;

public record PostCommand (Long memberId, String contents) {

}
